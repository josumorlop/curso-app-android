package es.crmone.app.repository.clientes

class ClientDTO (
    val cif: String,
    val razonSocial: String
)