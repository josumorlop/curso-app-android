package es.crmone.app.presentation.client

class Client (
    val cif: String,
    val razonSocial: String
)