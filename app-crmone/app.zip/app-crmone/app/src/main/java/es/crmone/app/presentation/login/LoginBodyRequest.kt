package es.crmone.app.presentation.login

class LoginBodyRequest (val email: String, val password: String)